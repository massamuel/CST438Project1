package edu.csumb.spoplack.project1samryanjamesjose;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateGradesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_grades);
    }
}
