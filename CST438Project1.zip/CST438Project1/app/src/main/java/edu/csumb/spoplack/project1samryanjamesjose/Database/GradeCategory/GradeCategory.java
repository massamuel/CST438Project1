package edu.csumb.spoplack.project1samryanjamesjose.Database.GradeCategory;

import androidx.room.Entity;

@Entity(tableName = "grade_category_table")
public class GradeCategory {
}
